#
# Copyright 2025 Splunk Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
class ConfManagerException(Exception):
    """Exception raised by ConfManager class."""

    pass


class ConfStanzaNotExistException(Exception):
    """Exception raised by ConfFile class."""

    pass


class InvalidPortError(ValueError):
    """Exception raised when an invalid proxy port is provided."""

    pass


class InvalidHostnameError(ValueError):
    """Exception raised when an invalid proxy hostname is provided."""

    pass
