[filter_settings]
days_in_past = 
exclude_filters = 
filter_enabled = 
include_filters = 
