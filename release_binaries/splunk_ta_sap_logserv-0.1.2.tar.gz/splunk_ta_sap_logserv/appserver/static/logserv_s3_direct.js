/**
 * SAP LogServ TA — AWS S3 Direct (Generic S3 backfill / recovery screen)
 *
 * Creates and manages LogServ-scoped Generic S3 inputs (aws_s3://) inside
 * Splunk_TA_aws, from the signed-in user's browser session. Secondary channel:
 * SQS-Based S3 remains the steady-state path. This exists for backfill,
 * queue-less buckets and outage recovery.
 *
 * Design: logserv_s3_input_screen_design_v0.2_20260909.md, as corrected by the
 * session-117 adversarial review folded at that note's section 17a. Every
 * numbered reference below (B1..B8, L1-nn, L2-nn, L3-nn) points into 17a.
 *
 * Why this is a standalone view and not a third Configuration tab (17a, B1):
 * UCC serves every configuration tab from one MultipleModel and one handler.
 * FilterSettingsHandler.handleEdit dispatches on FIELD PRESENCE, so a third
 * tab's payload (no filter_enabled) reads as filter_enabled=False and
 * _generate_filter_configs then CLEARS local/transforms.conf + local/props.conf
 * and mirrors the cleared files to deployment-apps/. A standalone view never
 * touches that handler, so the Data TA needs no Python change.
 *
 * Security boundaries — the four encoders. Validation patterns are UX gates a
 * user can bypass in devtools (L2-13); these always execute:
 *   enc()        every REST body field and every data-derived path segment
 *   shq()        every value interpolated into the generated shell command
 *   confValue()  every value interpolated into the generated conf stanza
 *   textContent  every value rendered into the DOM
 *
 * There is deliberately no HTML-escape helper here. Every value reaches the
 * DOM through textContent, so one is never needed — and an available esc()
 * invites use in a REST body, a shell command or a conf value, where
 * HTML-escaping is the WRONG encoding and silently corrupts the value
 * (17a, L2-03).
 */
/*
 * Loaded as a plain script, NOT as an AMD module (session-117 rendered pass).
 *
 * The first version wrapped everything in an anonymous define(). Splunk 9.4's
 * loader does fetch and evaluate a dashboard's script= asset, but it never
 * attributes an anonymous define() from one to a module name: it queues the
 * factory, then rejects it with RequireJS's "Mismatched anonymous define()
 * module". The file loaded, the factory never ran, and the panel sat on its
 * "Loading…" placeholder with nothing visibly wrong on the page — the only
 * trace was that one console error. A self-executing function has no such
 * dependency: the body runs the moment the file is evaluated.
 *
 * Confirmed on hf-01 by removing the define() and changing nothing else: the
 * screen renders from script= alone. No define() call is made now — nothing in
 * the app depends on this module, and a second anonymous define() would only
 * re-raise the same loader error in the customer's console.
 */
(function () {
    'use strict';

    /*
     * Idempotence. Splunk loads this once per page, but the file is also
     * require()-able by hand, and a loader change could evaluate it twice —
     * which did happen while the load path above was being diagnosed. Booting
     * twice would render the screen twice into the same panel.
     */
    var LOADED_FLAG = '__logservS3DirectLoaded';
    if (window[LOADED_FLAG]) { return; }

    /* ---------------------------------------------------------------- *
     * Constants
     * ---------------------------------------------------------------- */

    var PROXY = '/en-US/splunkd/__raw';
    var AWS_NS = PROXY + '/servicesNS/nobody/Splunk_TA_aws';
    var TA_NS = PROXY + '/servicesNS/nobody/splunk_ta_sap_logserv';
    var S3_EP = AWS_NS + '/splunk_ta_aws_aws_s3';
    var SQS_EP = AWS_NS + '/splunk_ta_aws_aws_sqs_based_s3';
    var ACCOUNTS_EP = AWS_NS + '/splunk_ta_aws_aws_all_accounts';
    var ROLES_EP = AWS_NS + '/splunk_ta_aws_iam_roles';
    var NATIVE_S3_EP = PROXY + '/servicesNS/nobody/Splunk_TA_aws/data/inputs/aws_s3';

    var CURRENT_CONTEXT = PROXY + '/services/authentication/current-context';
    var SERVER_INFO = PROXY + '/services/server/info';
    var APPS_LOCAL = PROXY + '/services/apps/local';
    var INDEXES_EP = PROXY + '/services/data/indexes';
    var DEPLOY_PUSH = PROXY + '/services/splunk_ta_sap_logserv/deployment_push';
    var DEPLOY_CLIENT = PROXY + '/services/deployment/client/serverclasses';
    var FILTER_SETTINGS =
        TA_NS + '/splunk_ta_sap_logserv_settings/filter_settings';

    /* Validated against this exact add-on version. A minor release can move
     * field names, defaults and handler behaviour, and three of the four
     * create/update asymmetries actually originate in splunktaucclib, which
     * the add-on upgrades independently (L1-07, L1-08). Exact-version
     * allowlist, advisory banner on anything else. */
    var VALIDATED_TA_AWS_VERSIONS = ['8.1.0'];

    var NAME_PREFIX = 'logserv_backfill_';
    var KEY_ROOT = 'logserv/';

    /* Vendor default. NOT a safety cap: max_items is declared in the input
     * scheme and never read by the 8.1.0 loader, so it bounds nothing
     * (L3-10). Blast radius is controlled by the prefix-depth block and by
     * terminal_scan_datetime being required. */
    var MAX_ITEMS = '100000';

    /* Blank does NOT mean "from the beginning of the prefix" — the add-on
     * substitutes now-7d (aws_s3_conf.py::_get_last_modified_time), so a
     * blank field silently skips every object written more than a week ago
     * (B6). We never send blank. */
    /* NOT the Unix epoch, deliberately.
     *
     * The add-on resolves the scan dates through Splunk's OWN
     * search/timeparser at RUNTIME (aws_s3_conf.py::_get_last_modified_time
     * -> ta_aws_common.py::parse_datetime), while CREATE validates locally
     * with strptime. Splunk 9.4.3 REJECTS every 1970 date - measured on
     * splunk-hf-01: GET search/timeparser?time=1970-01-01T00:00:00Z returns
     * HTTP 400 <msg type="FATAL">Invalid time.</msg>, and 1971-01-01T00:00:00Z
     * is the first accepted value. So a 1970 floor SAVES cleanly, the screen
     * reports success, and the input then raises on every poll into a broad
     * except that logs one line: zero events, forever - and scan-from is
     * read-only on edit, so it cannot be repaired from this screen.
     *
     * 2000-01-01 is below any object S3 can hold (S3 launched in 2006) and
     * clear of the cliff, so it is an effective "no lower bound" that the
     * server will actually parse. */
    var SCAN_FLOOR = '2000-01-01T00:00:00Z';

    /* The earliest value search/timeparser accepts; see SCAN_FLOOR. Anything
     * below this is refused client-side rather than saved and left inert. */
    var TIMEPARSER_FLOOR = '1971-01-01T00:00:00Z';

    /* The 30 clz_dir/clz_subdir pairs the Data TA routes, from the
     * @logserv_filter annotations in default/transforms.conf. Four contain a
     * colon, which every validator and encoder on this screen must tolerate
     * (L3-14, and 17a.4 — a proposed review fix got this wrong). */
    var CLZ_PAIRS = [
        'abap/audit', 'abap/dispatcher', 'abap/enqueueserver', 'abap/event',
        'abap/gateway', 'abap/icm', 'abap/messageserver', 'abap/sapstartsrv',
        'abap/workprocess', 'dns/binddns', 'hana/hanaaudit', 'hana/tracelogs',
        'linux/cron', 'linux/linux_secure', 'linux/localmessages',
        'linux/messages', 'linux/slapd', 'linux/sudolog', 'linux/warn',
        'proxy/squid', 'sap/saphostexec', 'sap/saprouter', 'sap/sapstartsrv',
        'scc/audit', 'scc/tracelogs', 'webdispatcher/accesslog',
        'windows/WinEventLog:Application', 'windows/WinEventLog:Powershell',
        'windows/WinEventLog:Security', 'windows/WinEventLog:System'
    ];

    var SOURCETYPE = 'sap_logserv_logs';
    var ACK_KEY_BASE = 'logserv.s3direct.tierAck.';

    /* The panel div declared by the view. Splunk inserts it asynchronously,
     * so start() polls for it — see the note there. 20 s of headroom. */
    var ROOT_ID = 'logserv-s3-direct-root';
    var ROOT_POLL_MS = 100;
    var MAX_ROOT_TRIES = 200;

    /* ---------------------------------------------------------------- *
     * Encoders — the security boundaries
     * ---------------------------------------------------------------- */

    function enc(v) {
        return encodeURIComponent(v === null || v === undefined ? '' : String(v));
    }

    /** Form-encode a flat object. Every key and value encoded (L2-03, L2-10):
     *  a bare '&' in a key prefix would otherwise inject a second parameter
     *  and could override the sourcetype this screen exists to guarantee. */
    function formEncode(obj) {
        var out = [];
        Object.keys(obj).forEach(function (k) {
            if (obj[k] === undefined || obj[k] === null) { return; }
            out.push(enc(k) + '=' + enc(obj[k]));
        });
        return out.join('&');
    }

    /** One REST path segment. encodeURIComponent turns '/' into %2F, which is
     *  what defeats a planted '../' input name collapsing in the URL parser
     *  and re-targeting the request (L2-02 / B4). */
    function pathSeg(v) {
        return enc(v);
    }

    /** Single-quote for a POSIX shell. The only escape inside '...' is '\'' .
     *  Mode 2's command is pasted by an administrator, so this is the boundary
     *  that matters most (L2-01 / B3). */
    function shq(v) {
        var s = String(v === null || v === undefined ? '' : v);
        if (/[\x00-\x1f\x7f]/.test(s)) {
            throw new Error('control character in value');
        }
        return "'" + s.split("'").join("'\\''") + "'";
    }

    /** A value safe to place after '<key> = ' in a .conf file. A trailing
     *  backslash is a legal S3 key character AND a conf line continuation,
     *  which would swallow the following sourcetype line and produce exactly
     *  the unrouted-data failure this screen exists to prevent (L2-06). */
    function confValue(v) {
        var s = String(v === null || v === undefined ? '' : v);
        if (/[\r\n\x00]/.test(s)) {
            throw new Error('control character in conf value');
        }
        if (/\\$/.test(s)) {
            throw new Error('value ends in a backslash, which continues the conf line');
        }
        return s;
    }

    function confStanzaName(v) {
        var s = String(v || '');
        if (!/^[A-Za-z0-9._\-\/]{1,255}$/.test(s)) {
            throw new Error('unsafe stanza name');
        }
        return s;
    }

    /* ---------------------------------------------------------------- *
     * DOM helpers — createElement/textContent only
     * ---------------------------------------------------------------- */

    function el(tag, attrs, kids) {
        var node = document.createElement(tag);
        if (attrs) {
            Object.keys(attrs).forEach(function (k) {
                if (k === 'text') { node.textContent = attrs[k]; }
                else if (k === 'cls') { node.className = attrs[k]; }
                else if (k.indexOf('on') === 0 && typeof attrs[k] === 'function') {
                    node.addEventListener(k.slice(2), attrs[k]);
                } else if (attrs[k] !== null && attrs[k] !== undefined) {
                    node.setAttribute(k, attrs[k]);
                }
            });
        }
        (kids || []).forEach(function (c) {
            if (c === null || c === undefined) { return; }
            node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
        });
        return node;
    }

    function clear(node) {
        while (node.firstChild) { node.removeChild(node.firstChild); }
    }

    /* ---------------------------------------------------------------- *
     * Transport
     * ---------------------------------------------------------------- */

    /** Scope the CSRF cookie to THIS Splunk Web instance. An unscoped match
     *  takes the first splunkweb_csrf_token_<port> cookie in document.cookie
     *  order, which on a host running two instances can be the other one's
     *  token — a 401 loop no retry can fix (L2-09). */
    function formKey() {
        var port = window.location.port || '80';
        var scoped = document.cookie.match(
            new RegExp('splunkweb_csrf_token_' + port + '=([^;]+)')
        );
        var any = scoped || document.cookie.match(/splunkweb_csrf_token_[0-9]+=([^;]+)/);
        return any ? decodeURIComponent(any[1]) : '';
    }

    function parseJson(text) {
        try { return JSON.parse(text); } catch (e) { return null; }
    }

    /**
     * One REST call.
     *
     * Retry policy (L2-09, L3-04): retry at most once, only on a 401 whose
     * body mentions CSRF, and only when the caller opts in. Creates NEVER opt
     * in — a create that timed out may in fact have succeeded, and a retry
     * would produce a second input on the same prefix, which genuinely
     * double-ingests because the checkpoint is keyed on the input name.
     */
    function req(url, opts, retryOnCsrf) {
        opts = opts || {};
        var init = {
            method: opts.method || 'GET',
            credentials: 'include',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        };
        if (init.method !== 'GET') {
            init.headers['X-Splunk-Form-Key'] = formKey();
            init.headers['Content-Type'] = 'application/x-www-form-urlencoded';
            if (opts.body !== undefined) { init.body = opts.body; }
        }
        var sep = url.indexOf('?') === -1 ? '?' : '&';
        return fetch(url + sep + 'output_mode=json', init).then(function (res) {
            return res.text().then(function (text) {
                if (res.status === 401 && retryOnCsrf && /csrf/i.test(text)) {
                    return req(url, opts, false);
                }
                return { status: res.status, ok: res.ok, text: text, json: parseJson(text) };
            });
        });
    }

    function entries(resp) {
        return (resp && resp.json && resp.json.entry) ? resp.json.entry : [];
    }

    /**
     * Translate a failure into something true and useful, without reflecting
     * raw vendor bodies or tracebacks to the viewer (L2-14, and section 9 of
     * the design). Full detail goes to the console for an admin only.
     */
    function explain(resp) {
        var t = resp.text || '';
        if (resp.status === 403 || /admin_all_objects/.test(t)) {
            return 'Your account lacks the admin_all_objects capability, which Splunk ' +
                'requires for this write. Use the generated stanza below instead.';
        }
        if (resp.status === 500 && /403|forbidden/i.test(t)) {
            return 'Your account lacks the admin_all_objects capability (the add-on ' +
                'reported it as a 500). Use the generated stanza below instead.';
        }
        if (resp.status === 401) { return 'Session or CSRF token rejected. Reload the page and retry.'; }
        /* The vendor's message is "Required field is missing: <name>", which
         * the original pattern did not match - so a missing required field
         * surfaced as the generic HTTP 400 fallback. */
        if (/required (arguments are missing|field is missing)/i.test(t)) {
            return 'The add-on rejected the payload as incomplete. This is a bug in this screen — ' +
                'please report it; nothing was changed.';
        }
        if (/is not supported by this handler/i.test(t)) {
            return 'The add-on rejected a field this screen sent. This is a bug in this screen — ' +
                'please report it; nothing was changed.';
        }
        if (/Wrong datetime with format/i.test(t)) {
            return 'The add-on rejected a datetime. It needs a complete date AND time; ' +
                'the value sent on the wire is YYYY-MM-DDTHH:MM:SSZ.';
        }
        return 'The request failed (HTTP ' + resp.status + '). See the browser console for detail.';
    }

    /* ---------------------------------------------------------------- *
     * Validation — UX gates. The encoders above are the real boundary.
     * ---------------------------------------------------------------- */

    var RE_NAME_SUFFIX = /^[a-z0-9][a-z0-9_-]{0,40}$/;
    var RE_FULL_NAME = /^[A-Za-z0-9][A-Za-z0-9._-]{0,254}$/;
    var RE_BUCKET = /^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/;
    var RE_DATETIME = /^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$/;

    /* Colon is required: logserv/windows/WinEventLog:Security/... is a real
     * prefix. '+' is legal in an S3 key too (17a.4). */
    var RE_KEY_NAME = /^logserv\/(?:[A-Za-z0-9][A-Za-z0-9._:+-]{0,127}\/)*(?:[A-Za-z0-9][A-Za-z0-9._:+-]{0,127})?$/;

    /* ---------------------------------------------------------------- *
     * Scan-window datetime: wire format <-> <input type="datetime-local">
     * ---------------------------------------------------------------- */

    /*
     * These two fields mean UTC. They end in Z and they bound the S3
     * object's LastModified, which S3 reports in UTC.
     *
     * <input type="datetime-local"> is deliberately timezone-LESS: it refuses
     * a value carrying a zone, and it renders in the VIEWER's locale. We do
     * NOT convert (session-117 Task 9). The picked wall-clock is stored as
     * UTC, exactly as the text field it replaces does today, and both labels
     * say UTC so nothing is implied that is not true. Converting would make
     * the value displayed differ from the value stored, which is worst on
     * edit - the case where an operator is reading back a window someone else
     * chose.
     *
     * RE_DATETIME above remains the gate. The picker is an input convenience,
     * never a trust boundary, which matters precisely because the fallback
     * path still accepts arbitrary text.
     */

    /* What the control can emit. step="1" keeps the seconds component, but
     * HTML value normalisation still drops a ":00", so both forms have to be
     * accepted - otherwise an exact-midnight pick would be passed through
     * unzoned and then rejected by RE_DATETIME. */
    var RE_PICKER_SEC = /^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}$/;
    var RE_PICKER_MIN = /^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}$/;

    /** Wire form (ends in Z) -> control form. Empty passes through: an empty
     *  datetime-local is legal and means "no value", which is exactly what an
     *  unset terminal_scan_datetime is. Anything RE_DATETIME does not
     *  recognise is returned unchanged and never reaches the control - see
     *  datetimeRenderable. */
    function toPickerValue(stored) {
        var s = String(stored === null || stored === undefined ? '' : stored);
        if (s === '') { return ''; }
        return RE_DATETIME.test(s) ? s.slice(0, -1) : s;
    }

    /** Control form -> wire form. Seconds are supplied when the browser
     *  normalised them away. Anything else passes through untouched, so that
     *  RE_DATETIME still gets to reject it rather than this function
     *  inventing a value that would then be stored. */
    function fromPickerValue(picked) {
        var s = String(picked === null || picked === undefined ? '' : picked);
        if (s === '') { return ''; }
        if (RE_PICKER_SEC.test(s)) { return s + 'Z'; }
        if (RE_PICKER_MIN.test(s)) { return s + ':00Z'; }
        return s;
    }

    /** True when this browser implements the type. One that does not reports
     *  type === 'text' after setAttribute, and MUST then be given the
     *  UNSTRIPPED value - the two paths store the same thing but display it
     *  differently, so the mapping has to follow the branch, not the field. */
    function supportsDatetimeLocal() {
        try {
            var probe = document.createElement('input');
            probe.setAttribute('type', 'datetime-local');
            return probe.type === 'datetime-local';
        } catch (e) {
            return false;
        }
    }

    /** True when the control can represent this value.
     *
     *  A record made by hand can legally carry something else: the add-on
     *  accepts Splunk relative time in a hand-written stanza, and a foreign
     *  record may carry an offset form. Assigning such a value to a
     *  datetime-local makes the browser silently blank the control, so the
     *  operator would be shown an empty field over a stored value they never
     *  cleared - and would then overwrite it by touching the field. Those get
     *  the text path, which can show what is actually there.
     *
     *  Structurally well formed is not the same as real: 2026-02-30 matches
     *  RE_DATETIME and still blanks the control, so round-trip through Date
     *  and require the exact same string back. */
    function datetimeRenderable(v) {
        var s = String(v === null || v === undefined ? '' : v);
        if (s === '') { return true; }
        if (!RE_DATETIME.test(s)) { return false; }
        /* HTML requires a year greater than zero, and Date happily round-trips
         * year 0000 - the one structurally-valid value that would still blank
         * the control. */
        if (s.slice(0, 4) === '0000') { return false; }
        var d = new Date(s);
        if (isNaN(d.getTime())) { return false; }
        return d.toISOString().slice(0, 19) + 'Z' === s;
    }

    /** Wire form for a Date, in UTC: YYYY-MM-DDTHH:MM:SSZ. */
    function isoZ(d) {
        return d.toISOString().slice(0, 19) + 'Z';
    }

    /**
     * The current calendar month, computed in UTC.
     *
     * Only `to` is a default now: newForm seeds scan-UNTIL from it so the run
     * terminates, while scan-FROM is SCAN_FLOOR because that end selects
     * rather than terminates. `from` is retained because a month is a window
     * and both edges are part of this function's contract - the scan-window
     * preset list that the widening advice invites would want it.
     *
     * UTC on purpose. These fields are UTC and the boundaries are month edges,
     * so deriving them from local time would put an operator WEST of Greenwich
     * into the previous month for the first hours of the 1st: at 02:00Z on the
     * 1st, Berlin reads 04:00 on the 1st but Chicago reads 21:00 on the 31st.
     */
    function monthWindow() {
        var now = new Date();
        var y = now.getUTCFullYear();
        var m = now.getUTCMonth();
        return {
            from: isoZ(new Date(Date.UTC(y, m, 1, 0, 0, 0))),
            /* day 0 of the next month is the last day of this one */
            to: isoZ(new Date(Date.UTC(y, m + 1, 0, 23, 59, 59)))
        };
    }

    /** The 30 routed pairs as ready-to-edit key prefixes. */
    function clzPrefixChoices() {
        return CLZ_PAIRS.map(function (p) { return KEY_ROOT + p + '/'; });
    }

    function segmentsOf(prefix) {
        return String(prefix || '').split('/').filter(function (s) { return s !== ''; });
    }

    /** The date partition a LogServ prefix carries, if it carries one:
     *  logserv/<clz_dir>/<clz_subdir>/YYYY[/MM[/DD]]/
     *
     *  Returns { start, end, label, granularity } or null. `start` and `end`
     *  are the first and last instants the partition can contain, so a caller
     *  asking "is EVERYTHING here behind the cutoff" tests `end` and fires
     *  only when the whole partition is.
     *
     *  Year- and month-only partitions are accepted because the depth gate
     *  below admits four segments and its own message asks for exactly that.
     *  Requiring the full six left both callers unable to evaluate the depth
     *  the screen recommends, so the days_in_past block could not fire where
     *  it was advertised (S-6). A month that is PRESENT but out of range is a
     *  typo rather than a year partition, and a day that Date.UTC would roll
     *  into the next month names a day the operator did not write - both are
     *  refused rather than silently widened. */
    function prefixDate(prefix) {
        var s = segmentsOf(prefix);
        if (s.length < 4) { return null; }
        var y = s[3], m = s[4], d = s[5];
        if (!/^[0-9]{4}$/.test(y)) { return null; }
        var Y = Number(y), M = null, D = null;
        if (s.length >= 5) {
            if (!/^[0-9]{2}$/.test(m)) { return null; }
            M = Number(m);
            if (M < 1 || M > 12) { return null; }
        }
        if (s.length >= 6) {
            if (!/^[0-9]{2}$/.test(d)) { return null; }
            D = Number(d);
        }
        var start, end, label, granularity;
        if (D !== null) {
            start = new Date(Date.UTC(Y, M - 1, D));
            end = new Date(Date.UTC(Y, M - 1, D, 23, 59, 59, 999));
            if (start.getUTCMonth() !== M - 1 || start.getUTCDate() !== D) { return null; }
            label = y + '-' + m + '-' + d;
            granularity = 'day';
        } else if (M !== null) {
            start = new Date(Date.UTC(Y, M - 1, 1));
            /* day 0 of the next month is the last day of this one */
            end = new Date(Date.UTC(Y, M, 0, 23, 59, 59, 999));
            label = y + '-' + m;
            granularity = 'month';
        } else {
            start = new Date(Date.UTC(Y, 0, 1));
            end = new Date(Date.UTC(Y, 11, 31, 23, 59, 59, 999));
            label = y;
            granularity = 'year';
        }
        if (isNaN(start.getTime()) || isNaN(end.getTime())) { return null; }
        return { start: start, end: end, label: label, granularity: granularity };
    }
    function clzPairOf(prefix) {
        var s = segmentsOf(prefix);
        return (s.length >= 3) ? s[1] + '/' + s[2] : null;
    }

    /**
     * Hard blocks and warnings for a proposed input.
     * Returns { errors: [], warnings: [] }.
     */
    function validate(form, env) {
        var errors = [];
        var warnings = [];

        if (!RE_NAME_SUFFIX.test(form.suffix || '')) {
            errors.push('Name suffix must be lower-case letters, digits, underscore or hyphen (max 41).');
        }
        if (!RE_BUCKET.test(form.bucket_name || '')) {
            errors.push('Bucket name is not a valid S3 bucket name.');
        }
        if (!form.aws_account) { errors.push('An AWS account is required.'); }

        /* Without the role the input authenticates as the bare IAM user and
         * returns an AccessDenied that reads like a bucket problem (design 1.2). */
        if (!form.aws_iam_role) {
            errors.push('An IAM role is required. Without it the input authenticates as the ' +
                'bare IAM user, which usually has no S3 access.');
        }
        /* host_name is set by the add-on on create only and never refreshed,
         * so aws_s3_region is the only region control that survives an edit
         * (L3-13). */
        if (!form.aws_s3_region) { errors.push('An AWS region is required.'); }

        /* The vendor declares index required=True with validator=None, so an
         * empty value is refused by splunktaucclib with
         * "Required field is missing: index" on BOTH create and update -
         * verified by invoking RestField.validate directly on splunk-hf-01.
         * Nothing is created and no events move, but without this check the
         * screen offers a Save that can only ever 400. Reachable two ways: by
         * choosing the not-set option on a record whose index is unlisted, and
         * on a fresh create whenever the indexes probe fails, since every probe
         * is .catch(() => null) and newForm then falls through to ''. */
        if (!form.index) { errors.push('An index is required.'); }

        if (!RE_KEY_NAME.test(form.key_name || '')) {
            errors.push('Key prefix must start with "' + KEY_ROOT + '" and contain only ' +
                'letters, digits, dot, underscore, hyphen, colon, plus and slash.');
        } else {
            var segs = segmentsOf(form.key_name);
            /* Block, do not warn. max_items caps nothing (L3-10) and a bare
             * logserv/ scan enumerates the whole archive with no cancel. */
            if (segs.length < 4) {
                errors.push('Key prefix is too broad. Scope it to at least ' +
                    'logserv/<clz_dir>/<clz_subdir>/<YYYY>/ — a wider prefix enumerates the ' +
                    'whole archive and cannot be stopped except by deleting the input.');
            }
            var pair = clzPairOf(form.key_name);
            if (pair && CLZ_PAIRS.indexOf(pair) === -1) {
                warnings.push('"' + pair + '" is not one of the 30 log types the Data TA routes. ' +
                    'Events under it will land at the fallback sourcetype.');
            }
        }

        if (!RE_DATETIME.test(form.initial_scan_datetime || '')) {
            errors.push('Scan-from must be a complete date AND time. It is sent as YYYY-MM-DDTHH:MM:SSZ.');
        }
        /* Required so every input this screen creates self-terminates.
         * Unbounded polling is the SQS channel's job (L3-10). */
        if (!RE_DATETIME.test(form.terminal_scan_datetime || '')) {
            errors.push('Scan-until is required, and must be a complete date AND time. It is sent as YYYY-MM-DDTHH:MM:SSZ.');
        }
        /* RE_DATETIME is only a SHAPE test: 2026-02-30T00:00:00Z satisfies it
         * and is not a real date. The picker refuses to display such a value,
         * so it can now only arrive by hand or from a record made elsewhere -
         * say so here rather than letting the add-on answer with a 400 that
         * reads like a formatting problem. */
        [['initial_scan_datetime', 'Scan-from'],
         ['terminal_scan_datetime', 'Scan-until']].forEach(function (pair) {
            var v = form[pair[0]] || '';
            if (RE_DATETIME.test(v) && !datetimeRenderable(v)) {
                errors.push(pair[1] + ' is not a real date and time.');
            }
            /* Shape and reality are not enough: the value must also be one
             * Splunk's search/timeparser will accept, because the add-on
             * resolves these fields through it on EVERY poll while validating
             * only locally on create (see SCAN_FLOOR). Without this a typed
             * 1970 date reproduces the same save-clean-then-fetch-nothing
             * failure that fixing the default removed. */
            if (RE_DATETIME.test(v) && datetimeRenderable(v) &&
                Date.parse(v) < Date.parse(TIMEPARSER_FLOOR)) {
                errors.push(pair[1] + ' must be ' + TIMEPARSER_FLOOR.slice(0, 10) +
                    ' or later. Splunk rejects earlier dates, and the add-on resolves ' +
                    'this field through Splunk on every poll - the input would save ' +
                    'and then fetch nothing.');
            }
        });

        /* The vendor validates this range in handleCreate only, so an edit
         * would otherwise be accepted and produce a permanently inert
         * input (L3-07). We enforce it on both paths. */
        if (RE_DATETIME.test(form.initial_scan_datetime || '') &&
            RE_DATETIME.test(form.terminal_scan_datetime || '')) {
            if (form.terminal_scan_datetime <= form.initial_scan_datetime) {
                errors.push('Scan-until must be later than scan-from.');
            }
        }

        Array.prototype.push.apply(warnings, filterInterference(form, env));
        Array.prototype.push.apply(warnings, sqsOverlap(form, env));
        return { errors: errors, warnings: warnings };
    }

    /**
     * The Data TA's own index-time filter runs on this same forwarder and can
     * nullQueue everything this screen ingests (B7). days_in_past compares the
     * event's embedded envelope _time against midnight UTC N days ago, so a
     * historical backfill is exactly what it drops.
     */
    function filterInterference(form, env) {
        var out = [];
        var f = env.filterSettings;
        if (!f || f.filter_enabled !== '1') { return out; }

        var days = parseInt(f.days_in_past, 10);
        var part = prefixDate(form.key_name);
        if (days > 0 && part) {
            var midnight = new Date();
            midnight.setUTCHours(0, 0, 0, 0);
            var cutoff = new Date(midnight.getTime() - days * 86400000);
            /* Test the NEWEST instant the partition can hold. Testing the
             * oldest would block a 2025/ prefix whose December days still
             * pass, and the claim below - that the backfill produces nothing
             * - would then be false. */
            if (part.end.getTime() < cutoff.getTime()) {
                var tail = 'this forwarder’s days_in_past = ' + days + ' cutoff. They will ' +
                    'be dropped to nullQueue at index time and the backfill will produce ' +
                    'nothing. Raise days_in_past on the Configuration → Filters tab first.';
                if (part.granularity === 'day') {
                    out.push('BLOCKING: events under this prefix are dated ' + part.label +
                        ', which is ' +
                        Math.round((cutoff.getTime() - part.start.getTime()) / 86400000) +
                        ' day(s) older than ' + tail);
                } else {
                    out.push('BLOCKING: every event under this prefix is dated ' + part.label +
                        ', and even the newest of them — ' +
                        part.end.toISOString().slice(0, 10) + ' — is ' +
                        Math.round((cutoff.getTime() - part.end.getTime()) / 86400000) +
                        ' day(s) older than ' + tail);
                }
            }
        }
        var pair = clzPairOf(form.key_name);
        var inc = String(f.include_filters || '*').trim();
        if (pair && inc && inc !== '*') {
            var allowed = inc.split(',').some(function (p) {
                p = p.trim();
                if (!p) { return false; }
                if (p.slice(-1) === '*') { return pair.indexOf(p.slice(0, -1)) === 0; }
                return p === pair;
            });
            if (!allowed) {
                out.push('BLOCKING: this forwarder’s include filter does not cover "' + pair +
                    '", so these events are dropped at index time.');
            }
        }
        var exc = String(f.exclude_filters || '').trim();
        if (pair && exc) {
            var excluded = exc.split(',').some(function (p) {
                p = p.trim();
                if (!p) { return false; }
                if (p.slice(-1) === '*') { return pair.indexOf(p.slice(0, -1)) === 0; }
                return p === pair;
            });
            if (excluded) {
                out.push('BLOCKING: this forwarder’s exclude filter drops "' + pair + '".');
            }
        }
        return out;
    }

    /**
     * The Generic S3 and SQS-Based S3 inputs share no state and both write
     * sourcetype=sap_logserv_logs into the same index from the same bucket, so
     * backfilling a window SQS is still delivering duplicates it (L3-09).
     */
    function sqsOverlap(form, env) {
        var part = prefixDate(form.key_name);
        if (!part) { return []; }
        /* The newest instant again: a year- or month-wide prefix reaches into
         * the last two days even though it starts long before them. */
        var ageDays = (Date.now() - part.end.getTime()) / 86400000;
        if (ageDays > 2) { return []; }
        var names = (env.sqsInputs || []).map(function (e) { return e.name; });
        return ['This prefix covers dates within the last two days, which the SQS-Based S3 input' +
            (names.length ? ' (' + names.join(', ') + ')' : '') + ' is probably still delivering. ' +
            'Objects already delivered will be ingested a SECOND time — the two inputs do not ' +
            'share state. Prefer a closed date partition.'];
    }
    /** Applied to records reconstructed from the add-on. A record failing this
     *  is shown read-only rather than blocking Save, because our patterns are
     *  deliberately stricter than the vendor's and would otherwise lock an
     *  operator out of a record the looser validator allowed (L3-11, L2-07). */
    function recordIssues(rec) {
        var out = [];
        if (!RE_FULL_NAME.test(rec.name || '')) {
            out.push('name is not safe to address through this screen');
        }
        if (rec.bucket_name && !RE_BUCKET.test(rec.bucket_name)) {
            out.push('bucket name is outside this screen’s pattern');
        }
        if (rec.key_name && !RE_KEY_NAME.test(rec.key_name)) {
            out.push('key prefix is outside this screen’s pattern');
        }
        return out;
    }

    /* ---------------------------------------------------------------- *
     * Environment probe and tier gating
     * ---------------------------------------------------------------- */

    function probe() {
        var env = {
            capabilities: [], mode: 'assisted',
            awsTa: null, awsTaPresent: false, awsTaDisabled: false, awsTaVersion: null,
            isCloud: false, isDS: false, guid: '',
            accounts: [], roles: [], indexes: [], inputs: [], sqsInputs: [],
            filterSettings: null, dsManagedAwsTa: null, probeFailed: false
        };

        return Promise.all([
            req(CURRENT_CONTEXT).catch(function () { return null; }),
            req(APPS_LOCAL + '?search=' + enc('name=Splunk_TA_aws')).catch(function () { return null; }),
            req(SERVER_INFO).catch(function () { return null; }),
            req(DEPLOY_PUSH).catch(function () { return null; }),
            req(DEPLOY_CLIENT).catch(function () { return null; }),
            req(FILTER_SETTINGS).catch(function () { return null; })
        ]).then(function (r) {
            var ctx = r[0], apps = r[1], info = r[2], push = r[3], dc = r[4], fs = r[5];

            /* Fail safe: any failure to establish capability selects Assisted
             * mode. A button that then 403s is worse than a correct command. */
            if (ctx && ctx.ok) {
                var c = entries(ctx)[0];
                env.capabilities = (c && c.content && c.content.capabilities) || [];
            } else {
                env.probeFailed = true;
            }
            env.mode = env.capabilities.indexOf('admin_all_objects') !== -1 ? 'managed' : 'assisted';

            var appEntry = entries(apps)[0];
            if (appEntry) {
                env.awsTa = appEntry;
                env.awsTaVersion = (appEntry.content && appEntry.content.version) || null;
                /* /services/apps/local lists DISABLED apps too, so presence
                 * alone is not enough (L1-03). */
                env.awsTaDisabled = !!(appEntry.content && appEntry.content.disabled);
                env.awsTaPresent = !env.awsTaDisabled;
            }

            if (info && info.ok) {
                var ic = entries(info)[0];
                var content = (ic && ic.content) || {};
                env.isCloud = String(content.instance_type || '').toLowerCase().indexOf('cloud') !== -1;
                env.guid = content.guid || '';
            }

            /* Reuse the Data TA's shipped detector rather than re-parsing
             * server_roles: it has a phone-home fallback that role parsing
             * alone misses (L1-11). */
            if (push && push.ok) {
                var pe = entries(push)[0];
                var pc = (pe && pe.content) || {};
                env.isDS = pc.is_deployment_server === true || pc.is_deployment_server === '1';
            }

            /* If Splunk_TA_aws is itself DS-managed, every input created here
             * is destroyed on the next deployment push and this screen's list
             * is the only record (B2). Best effort: unknown on probe failure,
             * and we make no claim in that case. */
            if (dc && dc.ok) {
                env.dsManagedAwsTa = JSON.stringify(dc.json || {}).indexOf('Splunk_TA_aws') !== -1;
            }

            if (fs && fs.ok) {
                var fe = entries(fs)[0];
                env.filterSettings = (fe && fe.content) || null;
            }

            if (!env.awsTaPresent) { return env; }

            return Promise.all([
                req(ACCOUNTS_EP + '?count=0').catch(function () { return null; }),
                req(ROLES_EP + '?count=0').catch(function () { return null; }),
                req(INDEXES_EP + '?count=0&search=' + enc('disabled=0')).catch(function () { return null; }),
                req(S3_EP + '?count=0').catch(function () { return null; }),
                req(SQS_EP + '?count=0').catch(function () { return null; })
            ]).then(function (rr) {
                env.accounts = entries(rr[0]).map(function (e) {
                    return { name: e.name, account_id: (e.content || {}).account_id || '' };
                });
                env.roles = entries(rr[1]).map(function (e) { return { name: e.name }; });
                env.indexes = entries(rr[2]).map(function (e) { return e.name; })
                    .filter(function (n) { return n.charAt(0) !== '_'; });
                env.inputs = entries(rr[3]).map(toRecord);
                env.sqsInputs = entries(rr[4]).map(function (e) { return { name: e.name }; });
                env.hasEnabledAwsInput =
                    entries(rr[3]).concat(entries(rr[4])).some(function (e) {
                        return e.content && e.content.disabled === false;
                    });
                return env;
            });
        });
    }

    function toRecord(e) {
        var c = e.content || {};
        return {
            name: e.name,
            aws_account: c.aws_account || '',
            aws_iam_role: c.aws_iam_role || '',
            aws_s3_region: c.aws_s3_region || '',
            bucket_name: c.bucket_name || '',
            key_name: c.key_name || '',
            initial_scan_datetime: c.initial_scan_datetime || '',
            terminal_scan_datetime: c.terminal_scan_datetime || '',
            polling_interval: c.polling_interval || '',
            index: c.index || '',
            sourcetype: c.sourcetype || '',
            disabled: c.disabled === true || c.disabled === '1',
            raw: c
        };
    }

    /** Ours by function (feeds the pipeline) vs ours by claim (we made it). */
    function isLogServInput(rec) { return rec.sourcetype === SOURCETYPE; }
    function isOurName(rec) { return String(rec.name || '').indexOf(NAME_PREFIX) === 0; }

    /* ---------------------------------------------------------------- *
     * Payload builders — separate by construction
     *
     * name is sent ONLY by buildCreate. Sending it on an update does not
     * rename, it forks the input, and two inputs over one prefix genuinely
     * double-ingest because the checkpoint is keyed on the input name
     * (17a.2). The update builder cannot express a name at all.
     * ---------------------------------------------------------------- */

    function commonFields(form) {
        return {
            aws_account: form.aws_account,
            aws_iam_role: form.aws_iam_role,
            aws_s3_region: form.aws_s3_region,
            bucket_name: form.bucket_name,
            key_name: form.key_name,
            terminal_scan_datetime: form.terminal_scan_datetime,
            polling_interval: form.polling_interval || '1800',
            index: form.index,
            sourcetype: SOURCETYPE,
            /* Rejected without it on EVERY call, not just create. */
            parse_csv_with_delimiter: ',',
            parse_csv_with_header: '0',
            max_items: MAX_ITEMS,
            recursion_depth: '-1',
            character_set: 'auto',
            is_secure: '1'
        };
    }

    function buildCreate(form) {
        var p = commonFields(form);
        p.name = NAME_PREFIX + form.suffix;
        /* Seeds the resume watermark, and ONLY on create — see buildUpdate. */
        p.initial_scan_datetime = form.initial_scan_datetime;
        return p;
    }

    /**
     * initial_scan_datetime is deliberately absent: the add-on seeds its
     * watermark from it only when no checkpoint exists and reads the stored
     * watermark thereafter, so editing it is a silent no-op (L3-05). The
     * editor renders it read-only and we do not pretend to send it.
     */
    function buildUpdate(form) {
        return commonFields(form);
    }

    /* ---------------------------------------------------------------- *
     * Mode 2 artifacts
     *
     * Built once, safely, and the SAME string is displayed and copied. Reading
     * the text back out of the DOM would decode the HTML escaping and hand the
     * administrator the raw payload (L2-05).
     * ---------------------------------------------------------------- */

    function buildStanza(form) {
        var name = confStanzaName(NAME_PREFIX + form.suffix);
        var p = buildCreate(form);
        var lines = ['[aws_s3://' + name + ']'];
        Object.keys(p).forEach(function (k) {
            if (k === 'name') { return; }
            lines.push(k + ' = ' + confValue(p[k]));
        });
        /* The UCC endpoint rejects _meta, so Mode 1 cannot stamp it while a
         * hand-written stanza can. Every SQS input on the fleet carries it and
         * cloud_provider is a rollup grain dimension, so omitting it would
         * attribute backfilled events differently from their neighbours
         * (L3-08). */
        lines.push('_meta = cloud_provider::aws');
        return lines.join('\n');
    }

    function buildCurl(form) {
        var p = buildCreate(form);
        var host = window.location.hostname;
        var out = [
            '# Run as a Splunk administrator on ' + host + '.',
            '# curl prompts for the password; do not type it on the command line.',
            'curl -k -u ' + shq('<your-splunk-username>') + ' \\',
            '  ' + shq('https://' + host + ':8089/servicesNS/nobody/Splunk_TA_aws/data/inputs/aws_s3') + ' \\'
        ];
        var keys = Object.keys(p);
        keys.forEach(function (k, i) {
            out.push('  --data-urlencode ' + shq(k + '=' + p[k]) + (i === keys.length - 1 ? '' : ' \\'));
        });
        return out.join('\n');
    }

    /* ---------------------------------------------------------------- *
     * Rendering
     * ---------------------------------------------------------------- */

    var root, state = { env: null, editing: null, form: null };

    function banner(kind, title, lines) {
        var box = el('div', { cls: 'logserv-s3-banner logserv-s3-' + kind });
        box.appendChild(el('strong', { text: title }));
        (lines || []).forEach(function (t) { box.appendChild(el('p', { text: t })); });
        return box;
    }

    function copyable(label, content) {
        var wrap = el('div', { cls: 'logserv-s3-artifact' });
        var head = el('div', { cls: 'logserv-s3-artifact-head' }, [el('strong', { text: label })]);
        head.appendChild(el('button', {
            type: 'button', cls: 'btn', text: 'Copy',
            onclick: function () { copyText(content, head); }
        }));
        wrap.appendChild(head);
        wrap.appendChild(el('pre', { text: content }));
        return wrap;
    }

    /** navigator.clipboard is secure-context only and Splunk Web is commonly
     *  served over HTTP here, so the execCommand path is the live one (L2-05). */
    function copyText(text, host) {
        function done(ok) {
            var n = el('span', { cls: 'logserv-s3-copied', text: ok ? ' copied' : ' copy failed' });
            host.appendChild(n);
            setTimeout(function () { if (n.parentNode) { n.parentNode.removeChild(n); } }, 2000);
        }
        if (window.navigator && navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(function () { done(true); },
                function () { done(false); });
            return;
        }
        var ta = el('textarea', { cls: 'logserv-s3-clip' });
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        var ok = false;
        try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
        document.body.removeChild(ta);
        done(ok);
    }

    function paramTable(form) {
        /* An administrator is being asked to run this. Show them the
         * parameters, not just a blob (L2-08). */
        var rows = [
            ['Bucket', form.bucket_name], ['Key prefix', form.key_name],
            ['Index', form.index], ['Sourcetype', SOURCETYPE],
            ['AWS account', form.aws_account], ['IAM role', form.aws_iam_role],
            ['Region', form.aws_s3_region],
            ['Scan from (object write time, UTC)', form.initial_scan_datetime],
            ['Scan until (object write time, UTC)', form.terminal_scan_datetime]
        ];
        var tbl = el('table', { cls: 'logserv-s3-params' });
        rows.forEach(function (r) {
            tbl.appendChild(el('tr', null, [
                el('th', { text: r[0] }), el('td', { text: r[1] || '' })
            ]));
        });
        return tbl;
    }

    function renderList(container, env) {
        var section = el('div', { cls: 'logserv-s3-section' });
        section.appendChild(el('h3', { text: 'LogServ S3 inputs on this instance' }));

        var rows = env.inputs.filter(function (r) {
            return isLogServInput(r) || isOurName(r);
        });

        if (!rows.length) {
            section.appendChild(el('p', {
                text: 'No LogServ-scoped Generic S3 inputs are configured here.'
            }));
            container.appendChild(section);
            return;
        }

        var tbl = el('table', { cls: 'logserv-s3-table' });
        tbl.appendChild(el('tr', null, ['Name', 'Bucket', 'Key prefix', 'Scan until (UTC)', 'State', '']
            .map(function (h) { return el('th', { text: h }); })));

        rows.forEach(function (rec) {
            var issues = recordIssues(rec);
            var foreign = !isOurName(rec);
            var wrongRoute = isOurName(rec) && !isLogServInput(rec);

            var tr = el('tr', null, [
                el('td', { text: rec.name }),
                el('td', { text: rec.bucket_name }),
                el('td', { text: rec.key_name }),
                el('td', { text: rec.terminal_scan_datetime || '(unbounded)' }),
                el('td', { text: rec.disabled ? 'disabled' : 'enabled' })
            ]);

            var actions = el('td');
            if (issues.length) {
                /* Not addressable safely: no buttons, and say why (L2-02). */
                actions.appendChild(el('span', {
                    cls: 'logserv-s3-note',
                    text: 'read-only — ' + issues.join('; ')
                }));
            } else if (env.mode === 'managed') {
                actions.appendChild(el('button', {
                    type: 'button', cls: 'btn', text: 'Edit',
                    onclick: function () { startEdit(rec); }
                }));
                actions.appendChild(el('button', {
                    type: 'button', cls: 'btn',
                    text: rec.disabled ? 'Enable' : 'Disable',
                    onclick: function () { toggleInput(rec); }
                }));
                actions.appendChild(el('button', {
                    type: 'button', cls: 'btn btn-danger', text: 'Delete',
                    onclick: function () { confirmDelete(rec, foreign); }
                }));
            } else {
                actions.appendChild(el('span', { cls: 'logserv-s3-note', text: 'read-only' }));
            }
            tr.appendChild(actions);
            tbl.appendChild(tr);

            if (wrongRoute) {
                tr.appendChild(el('td'));
                tbl.appendChild(el('tr', null, [el('td', {
                    colspan: '6', cls: 'logserv-s3-warn',
                    text: 'Named like an input from this screen but its sourcetype is "' +
                        rec.sourcetype + '", so it is NOT routed through the Data TA pipeline.'
                })]));
            }
        });

        section.appendChild(tbl);
        section.appendChild(el('p', {
            cls: 'logserv-s3-note',
            text: 'A bounded run whose "scan until" has passed may be finished, still ' +
                'discovering, or interrupted — the add-on keeps that state in a checkpoint ' +
                'file this screen cannot read. Verify with the searches below before assuming ' +
                'a backfill completed.'
        }));
        container.appendChild(section);
    }

    function startEdit(rec) {
        state.editing = rec.name;
        state.form = {
            suffix: String(rec.name).indexOf(NAME_PREFIX) === 0
                ? String(rec.name).slice(NAME_PREFIX.length) : rec.name,
            aws_account: rec.aws_account, aws_iam_role: rec.aws_iam_role,
            aws_s3_region: rec.aws_s3_region, bucket_name: rec.bucket_name,
            key_name: rec.key_name,
            initial_scan_datetime: rec.initial_scan_datetime,
            terminal_scan_datetime: rec.terminal_scan_datetime,
            polling_interval: rec.polling_interval, index: rec.index
        };
        render();
    }

    function newForm(env) {
        /* The two ends of the default window are chosen for OPPOSITE reasons.
         *
         * scan-from is SCAN_FLOOR, because this bound SELECTS. It bounds
         * the object's LastModified, and SAP re-stages archives, so a lower
         * bound seeded from the current month finds only what was WRITTEN this
         * month: a historical backfill then selects nothing and still reports
         * success. Our own archive is the case in point - objects carrying
         * 2025-06-11 events have LastModified 2026-01-26. The widest lower
         * bound is the only one that cannot silently select nothing.
         *
         * scan-until is the end of the current month, because this bound
         * TERMINATES. An input whose terminal date never passes polls the
         * customer's archive forever.
         *
         * Neither may be BLANK, which the add-on reads as now-minus-7-days for
         * scan-from and as unbounded for scan-until (B6); both are explicit. */
        var win = monthWindow();
        return {
            suffix: '', aws_account: (env.accounts[0] || {}).name || '',
            aws_iam_role: (env.roles[0] || {}).name || '', aws_s3_region: '',
            bucket_name: '', key_name: KEY_ROOT,
            initial_scan_datetime: SCAN_FLOOR,
            terminal_scan_datetime: win.to, polling_interval: '1800',
            index: env.indexes.indexOf(SOURCETYPE) !== -1 ? SOURCETYPE : (env.indexes[0] || '')
        };
    }

    function field(label, key, opts) {
        opts = opts || {};
        var id = 'lsf-' + key;
        var wrap = el('div', { cls: 'logserv-s3-field' });
        wrap.appendChild(el('label', { for: id, text: label }));
        var input;
        var picker = false;
        if (opts.choices) {
            input = el('select', { id: id });
            /* A stored value this instance no longer offers must still be the
             * one on display. With no matching <option> the browser selects the
             * FIRST, while state.form keeps - and the write sends - the stored
             * value, so the control shows one account and saves another. That
             * is the same displays-one-sends-another defect datetimeRenderable
             * guards against on the scan fields, and it reaches all three
             * selects here: aws_account, aws_iam_role, and index - which is
             * filtered, so an input on an internal index shows the first
             * ordinary one.
             *
             * Carrying the stored value as its own option keeps display equal
             * to payload. The VALUE stays exact, so readBack is unaffected;
             * only the label says why it is there. Empty is included: a
             * hand-written stanza can legally omit aws_iam_role, and showing
             * the first role while sending '' is the same lie inverted.
             * validate() hard-blocks an empty account, role and index, so the
             * empty state is visible AND refused. A stale NON-empty value is
             * shown but still written as stored, which is deliberate: an edit
             * that only changes the prefix must not silently rewrite a field
             * the operator never touched. */
            var cur = state.form[key];
            var curStr = (cur === undefined || cur === null) ? '' : String(cur);
            var offered = (opts.choices || []).some(function (c) {
                return String(c) === curStr;
            });
            if (!offered) {
                /* Say only what we actually know. "Not available on this
                 * instance" would be a claim about the INSTANCE drawn from
                 * evidence that only describes OUR LIST, and it is false in the
                 * cases most likely to produce it: an internal index is hidden
                 * by our own charAt(0) !== '_' filter, a disabled index by the
                 * probe's disabled=0 search, and a failed probe is
                 * indistinguishable from an empty one because every probe is
                 * .catch(() => null). */
                var listUnread = !(opts.choices || []).length;
                var stale = el('option', {
                    value: curStr,
                    text: curStr === ''
                        ? '(not set)'
                        : curStr + (listUnread
                            ? ' - stored value; this list could not be read'
                            : ' - stored value, not in this list')
                });
                stale.setAttribute('selected', 'selected');
                input.appendChild(stale);
            }
            (opts.choices || []).forEach(function (c) {
                var o = el('option', { value: c, text: c });
                if (curStr === String(c)) { o.setAttribute('selected', 'selected'); }
                input.appendChild(o);
            });
        } else if (opts.datetime && supportsDatetimeLocal() &&
                   datetimeRenderable(state.form[key])) {
            /* step="1" is required: without it browsers drop the seconds
             * component from the control, and the wire format carries
             * seconds. */
            picker = true;
            input = el('input', { id: id, type: 'datetime-local', step: '1' });
            input.value = toPickerValue(state.form[key]);
        } else {
            input = el('input', { id: id, type: 'text' });
            input.value = state.form[key] === undefined ? '' : state.form[key];
        }
        if (opts.readonly) { input.setAttribute('disabled', 'disabled'); }
        /* Read back through the same branch that rendered. Assigning
         * input.value raw here would write an unzoned value into state.form,
         * and the add-on rejects anything that is not YYYY-MM-DDTHH:MM:SSZ. */
        function readBack() {
            return picker ? fromPickerValue(input.value) : input.value;
        }
        input.addEventListener('change', function () { state.form[key] = readBack(); });
        input.addEventListener('input', function () { state.form[key] = readBack(); });

        /* An optional "insert one of these" dropdown that PREFILLS the text box
         * and then resets itself. It is an action, not a second copy of the
         * field's state: leaving it showing a selection would let it drift from
         * the text the operator then edits, and a control that displays one
         * value while another is stored is the defect class this screen already
         * has to guard against elsewhere.
         *
         * No synthetic event is needed to refresh the live gate. This select is
         * inside the section, so its own change event bubbles to the delegated
         * listener there, and state.form is updated at the target before the
         * bubble reaches it. */
        /* Text branch only. These values are consumed in the CONTROL's own form:
         * handing a zoned wire value to a datetime-local, or a value no <option>
         * carries to a select, sets the control to '' and silently WIPES the
         * field. No call site combines them today; the guard keeps it that way. */
        if (opts.insert && opts.insert.length && !opts.readonly && !picker && !opts.choices) {
            var ins = el('select', { cls: 'logserv-s3-insert' });
            ins.appendChild(el('option', { value: '', text: opts.insertLabel || 'Insert…' }));
            opts.insert.forEach(function (v) {
                ins.appendChild(el('option', { value: v, text: v }));
            });
            ins.addEventListener('change', function () {
                if (!ins.value) { return; }
                input.value = ins.value;
                state.form[key] = readBack();
            });
            /* Reset on blur, not on change, and never steal focus. Some browsers
             * fire change on every arrow key while a closed select has focus; a
             * handler that reset the selection and moved focus away would then
             * let a keyboard-only operator reach the FIRST option and no other,
             * and the wrongly inserted prefix is a real routed pair, so nothing
             * downstream would flag it. Resetting on blur keeps the dropdown and
             * the text box in agreement whenever the operator is not looking at
             * the dropdown, which is the only window in which they could drift.
             * (Chrome 152 opens the listbox instead of cycling, so it does not
             * exhibit this - hence blur rather than a version check.) */
            ins.addEventListener('blur', function () { ins.value = ''; });
            wrap.appendChild(ins);
        }

        wrap.appendChild(input);
        if (opts.help) { wrap.appendChild(el('p', { cls: 'logserv-s3-help', text: opts.help })); }
        return wrap;
    }

    /**
     * Split a validation result into what BLOCKS and what merely warns.
     *
     * The render-time gate and the submit-time guard both go through here, so
     * they cannot disagree about what "blocked" means. That matters: if the
     * guard were looser than the gate it would admit a write the UI had
     * already refused to offer, and if it were stricter it would lock an
     * operator out of a record the gate had been happy to show.
     */
    function splitIssues(res) {
        return {
            soft: res.warnings.filter(function (w) { return w.indexOf('BLOCKING:') !== 0; }),
            hard: res.errors.concat(res.warnings
                .filter(function (w) { return w.indexOf('BLOCKING:') === 0; })
                .map(function (w) { return w.replace('BLOCKING: ', ''); }))
        };
    }

    function renderEditor(container, env) {
        var editing = !!state.editing;
        var section = el('div', { cls: 'logserv-s3-section' });
        section.appendChild(el('h3', {
            text: editing ? 'Edit ' + state.editing : 'Create a backfill input'
        }));

        if (editing) {
            section.appendChild(el('p', {
                cls: 'logserv-s3-note',
                text: 'The name cannot be changed — the add-on would create a second input ' +
                    'rather than rename this one, and both would ingest.'
            }));
        }

        section.appendChild(field('Name suffix', 'suffix', {
            readonly: editing,
            help: 'The input is named ' + NAME_PREFIX + '<suffix>.'
        }));
        section.appendChild(field('AWS account', 'aws_account',
            { choices: env.accounts.map(function (a) { return a.name; }) }));
        section.appendChild(field('IAM role', 'aws_iam_role',
            {
                choices: env.roles.map(function (r) { return r.name; }),
                help: 'Required. Without it the input authenticates as the bare IAM user and ' +
                    'returns an AccessDenied that looks like a bucket problem.'
            }));
        section.appendChild(field('AWS region', 'aws_s3_region', {
            help: 'Required. The add-on records the bucket endpoint on create only and never ' +
                'refreshes it, so this is the only region control that survives an edit.'
        }));
        section.appendChild(field('Bucket', 'bucket_name', {
            help: 'The bucket NAME on its own — not an ARN and not a URL. ' +
                'For example splunk-logserv-remote-bucket-perm, not ' +
                'arn:aws:s3:::splunk-logserv-remote-bucket-perm, not ' +
                's3://splunk-logserv-remote-bucket-perm and not an https:// endpoint. ' +
                'The region is set separately above.'
        }));
        section.appendChild(field('Key prefix', 'key_name', {
            insert: clzPrefixChoices(),
            insertLabel: 'Insert a log type… (' + CLZ_PAIRS.length + ' routed)',
            help: 'This is what selects your events. LogServ keys are ' +
                'logserv/<clz_dir>/<clz_subdir>/YYYY/MM/DD/, so the date here is the EVENT date. ' +
                'Pick a log type from the list to fill this in, then add the date you want — ' +
                'the box stays editable. Scope it to at least a single log type and year.'
        }));
        section.appendChild(field('Scan from (object write time, UTC)', 'initial_scan_datetime', {
            datetime: true,
            readonly: editing,
            help: editing
                ? 'Effective on create only. The add-on seeds its resume watermark from this the ' +
                  'first time the input runs and reads the stored watermark thereafter, so ' +
                  'changing it here would do nothing.'
                : 'Bounds the S3 object’s LAST-MODIFIED time — when SAP wrote it — not the ' +
                  'event timestamps inside it. Read as UTC, not as your local time, and the ' +
                  'time of day counts — a date on its own is not a complete value. Defaults ' +
                  'to 2000-01-01 at 00:00:00, which is below anything S3 can hold, so it ' +
                  'imposes no useful lower bound and the run takes everything written up to ' +
                  'the scan-until date. To restore that after narrowing, set the date to ' +
                  '2000-01-01 and the time to 00:00:00. Narrow it only if you know when the ' +
                  'objects were WRITTEN. SAP re-stages archives, so a 2025 event can sit in ' +
                  'an object written in 2026, and a window guessed from the event dates ' +
                  'selects nothing while still reporting success. Check the real write ' +
                  'times with: aws s3 ls s3://<bucket>/<prefix>'
        }));
        section.appendChild(field('Scan until (object write time, UTC)', 'terminal_scan_datetime', {
            datetime: true,
            help: (editing ? 'Required, so the run terminates. '
                : 'Required, so the run terminates. Defaults to the end of this month, ' +
                  'so the default window is everything written up to then. ') +
                'Also bounds object write time, not event time. Read as UTC, not as your ' +
                'local time, and set the time of day as well as the date — a date on its ' +
                'own is not a complete value.'
        }));
        section.appendChild(field('Poll interval (s)', 'polling_interval'));
        section.appendChild(field('Index', 'index', { choices: env.indexes }));

        /*
         * The gate has to be LIVE, not drawn once.
         *
         * This block used to run a single time per render, and nothing
         * re-renders when a field changes: the field handlers only mutate
         * state.form, and every render() call site is unreachable from typing.
         * Because newForm() starts with an empty suffix, the first render of a
         * create form ALWAYS had an error, so the button was never appended -
         * and no amount of correct typing could bring it back. Measured on the
         * shipped build: a fully and correctly filled form still rendered zero
         * buttons and kept all five stale "Cannot continue" banners, while
         * Assisted mode went on printing "Nothing generated". The create path
         * produced nothing in either mode; only Edit worked.
         *
         * Repainting just these three boxes - never the inputs - keeps the
         * caret and the open calendar popup untouched, which matters now that
         * two of the fields are datetime-local controls.
         */
        var gateBox = el('div');
        var bar = el('div', { cls: 'logserv-s3-actions' });
        var assistedBox = el('div');
        section.appendChild(gateBox);
        section.appendChild(bar);
        section.appendChild(assistedBox);

        function refreshGates() {
            clear(gateBox); clear(bar); clear(assistedBox);
            var iss = splitIssues(validate(state.form, env));
            iss.hard.forEach(function (e) {
                gateBox.appendChild(banner('error', 'Cannot continue', [e]));
            });
            iss.soft.forEach(function (w) {
                gateBox.appendChild(banner('warn', 'Check this', [w]));
            });
            if (env.mode === 'managed' && !iss.hard.length) {
                bar.appendChild(el('button', {
                    type: 'button', cls: 'btn btn-primary',
                    text: editing ? 'Save changes' : 'Create input',
                    onclick: function () { editing ? submitUpdate() : submitCreate(); }
                }));
            }
            /* Cancel must be inside the repaint, or it disappears on the first
             * keystroke and an operator editing a record has no way back. */
            if (editing) {
                bar.appendChild(el('button', {
                    type: 'button', cls: 'btn', text: 'Cancel',
                    onclick: function () { state.editing = null; state.form = newForm(env); render(); }
                }));
            }
            if (env.mode === 'assisted') {
                assistedBox.appendChild(renderAssisted(env, iss.hard.length > 0));
            }
        }

        /* Delegated, and on the BUBBLE phase: each field's own handler runs at
         * the target first, so state.form is already current by the time this
         * sees the event. Capture phase would read the value the operator had
         * just replaced. Delegation also covers the <select> fields for free,
         * which threading a callback through field() would not. */
        section.addEventListener('input', refreshGates);
        section.addEventListener('change', refreshGates);
        refreshGates();

        container.appendChild(section);
    }

    function renderAssisted(env, blocked) {
        var box = el('div', { cls: 'logserv-s3-section logserv-s3-assisted' });
        box.appendChild(el('h3', { text: 'Apply this as an administrator' }));
        box.appendChild(el('p', {
            text: 'Your account lacks the admin_all_objects capability that Splunk requires to ' +
                'create an input, so this screen generates the exact configuration instead. ' +
                'An administrator must review the parameters below and apply it.'
        }));
        if (blocked) {
            box.appendChild(banner('error', 'Nothing generated',
                ['Resolve the errors above first — this screen will not generate a command ' +
                 'from values it cannot validate.']));
            return box;
        }
        box.appendChild(paramTable(state.form));
        box.appendChild(el('p', {
            cls: 'logserv-s3-note',
            text: 'Administrator: confirm the bucket and key prefix with whoever asked for this ' +
                'before running it.'
        }));
        try {
            box.appendChild(copyable('inputs.conf stanza (Splunk_TA_aws/local/inputs.conf)',
                buildStanza(state.form)));
            box.appendChild(copyable('Equivalent REST call', buildCurl(state.form)));
        } catch (e) {
            box.appendChild(banner('error', 'Cannot generate a safe artifact', [String(e.message || e)]));
        }
        return box;
    }

    /* ---------------------------------------------------------------- *
     * Writes
     * ---------------------------------------------------------------- */

    var inFlight = false;

    /**
     * Refuse a write the gate would not have offered.
     *
     * The rendered gate is now live, so this should be unreachable - but it is
     * the boundary that always executes, and the value it is guarding against
     * is the one the vendor does NOT reject: an empty scan bound is skipped by
     * splunktaucclib's validator (falsy), declared required=False by the
     * add-on's handler, and then turned into now-minus-7-days for a blank
     * scan-from or the unbounded "z" sentinel for a blank scan-until. Both
     * report success. Uses the same predicate as the gate, so it can never
     * refuse something the button was willing to offer.
     */
    function submitCreate() {
        if (inFlight) { return; }
        var hard = splitIssues(validate(state.form, state.env)).hard;
        if (hard.length) { return flash('error', 'Cannot create this input', hard); }
        var env = state.env;
        var name = NAME_PREFIX + state.form.suffix;

        /* Re-list first: creating over an existing name would fire the
         * add-on's create hook, which DELETES that input's checkpoint and
         * would re-ingest everything it had already collected (17a.2). */
        inFlight = true;
        req(S3_EP + '?count=0').then(function (resp) {
            var exists = entries(resp).some(function (e) { return e.name === name; });
            if (exists) {
                inFlight = false;
                return flash('error', 'An input named ' + name + ' already exists',
                    ['Creating over it would reset its checkpoint and re-ingest everything it ' +
                     'has already collected. Pick another name.']);
            }
            var body = formEncode(buildCreate(state.form));
            /* Never auto-retry a create (17a.2). */
            return req(S3_EP, { method: 'POST', body: body }, false).then(function (r) {
                inFlight = false;
                if (!r.ok) {
                    console.warn('LogServ S3 Direct: create failed', r.status, r.text);
                    return flash('error', 'Could not create the input', [explain(r)]);
                }
                return stampMeta(name).then(function (metaNote) {
                    var notes = ['The input starts polling immediately.'];
                    if (metaNote) { notes.push(metaNote); }
                    flash('ok', 'Created ' + name, notes);
                    reload();
                });
            });
        }).catch(function (e) {
            inFlight = false;
            console.warn('LogServ S3 Direct: create error', e);
            flash('error', 'Could not create the input', ['The request did not complete. ' +
                'Re-check the list before retrying — do not assume it failed.']);
        });
    }

    /**
     * The UCC endpoint has no _meta field, so Mode 1 cannot stamp
     * cloud_provider the way every SQS input on the fleet does. Try the native
     * endpoint; if it refuses, say so rather than leaving the operator with
     * differently-attributed data and no idea why (L3-08).
     */
    function stampMeta(name) {
        return req(NATIVE_S3_EP + '/' + pathSeg(name),
            { method: 'POST', body: formEncode({ _meta: 'cloud_provider::aws' }) }, true)
            .then(function (r) {
                if (r.ok) { return ''; }
                return 'Note: this Splunk build would not accept the cloud_provider stamp on the ' +
                    'input, so these events will not carry cloud_provider=aws. Add ' +
                    '"_meta = cloud_provider::aws" to the stanza by hand if you need the ' +
                    'Multi-Cloud dashboard to attribute them.';
            })
            .catch(function () { return ''; });
    }

    function submitUpdate() {
        if (inFlight || !state.editing) { return; }
        var hard = splitIssues(validate(state.form, state.env)).hard;
        if (hard.length) { return flash('error', 'Cannot save these changes', hard); }
        inFlight = true;
        var body = formEncode(buildUpdate(state.form));
        req(S3_EP + '/' + pathSeg(state.editing), { method: 'POST', body: body }, true)
            .then(function (r) {
                inFlight = false;
                if (!r.ok) {
                    console.warn('LogServ S3 Direct: update failed', r.status, r.text);
                    return flash('error', 'Could not save changes', [explain(r)]);
                }
                flash('ok', 'Saved ' + state.editing, []);
                state.editing = null;
                reload();
            }).catch(function (e) {
                inFlight = false;
                console.warn('LogServ S3 Direct: update error', e);
                flash('error', 'Could not save changes', ['The request did not complete.']);
            });
    }

    function toggleInput(rec) {
        if (inFlight) { return; }
        inFlight = true;
        var action = rec.disabled ? 'enable' : 'disable';
        req(NATIVE_S3_EP + '/' + pathSeg(rec.name) + '/' + action, { method: 'POST' }, true)
            .then(function (r) {
                inFlight = false;
                if (!r.ok) {
                    console.warn('LogServ S3 Direct: toggle failed', r.status, r.text);
                    return flash('error', 'Could not ' + action + ' ' + rec.name, [explain(r)]);
                }
                flash('ok', rec.name + ' ' + action + 'd', action === 'disable'
                    ? ['Disabling stops further polling. It does not resume an interrupted run — ' +
                       'the add-on will not re-fetch objects it has already passed.']
                    : []);
                reload();
            }).catch(function () {
                inFlight = false;
                flash('error', 'Could not ' + action + ' ' + rec.name, ['The request did not complete.']);
            });
    }

    function confirmDelete(rec, foreign) {
        var msg = 'Delete ' + rec.name + '?\n\n' +
            'This does not remove any events already indexed. If you recreate an input with ' +
            'the same name, the add-on resets its checkpoint and re-ingests everything under ' +
            'the prefix a second time.';
        if (foreign) {
            msg += '\n\nThis input was NOT created by this screen. Type the name to confirm.';
            var typed = window.prompt(msg, '');
            if (typed !== rec.name) { return; }
        } else if (!window.confirm(msg)) {
            return;
        }
        inFlight = true;
        req(S3_EP + '/' + pathSeg(rec.name), { method: 'DELETE' }, true).then(function (r) {
            inFlight = false;
            if (!r.ok) {
                console.warn('LogServ S3 Direct: delete failed', r.status, r.text);
                return flash('error', 'Could not delete ' + rec.name, [explain(r)]);
            }
            flash('ok', 'Deleted ' + rec.name, []);
            reload();
        }).catch(function () {
            inFlight = false;
            flash('error', 'Could not delete ' + rec.name, ['The request did not complete.']);
        });
    }

    /* ---------------------------------------------------------------- *
     * Gating and top-level render
     * ---------------------------------------------------------------- */

    var flashBox = null;
    function flash(kind, title, lines) {
        if (!flashBox) { return; }
        clear(flashBox);
        flashBox.appendChild(banner(kind, title, lines));
    }

    function ackKey(env) { return ACK_KEY_BASE + (env.guid || 'unknown'); }

    function tierGate(container, env) {
        /* Gate A — Splunk-managed instance. Never write from here. */
        if (env.isCloud) {
            container.appendChild(banner('warn', 'This is a Splunk-managed instance',
                ['Direct S3 polling runs on the instance that holds the input, so it belongs on ' +
                 'a heavy forwarder you manage. This screen will not write here; use the ' +
                 'generated configuration below on your forwarder.']));
            env.mode = 'assisted';
            return true;
        }
        /* Gate B — positive evidence this instance already ingests from AWS. */
        if (env.hasEnabledAwsInput) { return true; }
        /* Gate C — no evidence either way; acknowledge once per instance. */
        var acked = false;
        try { acked = window.localStorage.getItem(ackKey(env)) === '1'; } catch (e) { acked = false; }
        if (acked) { return true; }

        container.appendChild(banner('warn', 'No AWS inputs are configured on this instance',
            ['An input created here polls S3 from THIS instance and forwards from here. On a ' +
             'search head or an indexer that is usually not what you want — create it on the ' +
             'heavy forwarder that already collects your LogServ data.',
             'If another instance already polls this bucket and prefix, both will ingest it and ' +
             'you will get duplicate events. Nothing on this screen can detect that.']));
        var bar = el('div', { cls: 'logserv-s3-actions' });
        bar.appendChild(el('button', {
            type: 'button', cls: 'btn btn-primary', text: 'Create inputs here anyway',
            onclick: function () {
                try { window.localStorage.setItem(ackKey(env), '1'); } catch (e) { /* ignore */ }
                render();
            }
        }));
        container.appendChild(bar);
        return false;
    }

    function render() {
        var env = state.env;
        clear(root);

        flashBox = el('div');
        root.appendChild(flashBox);

        root.appendChild(el('p', {
            cls: 'logserv-s3-lede',
            text: 'Generic S3 polls a bucket prefix directly, with no queue. Use it for backfill, ' +
                'for outage recovery, and for buckets with no notification wiring. SQS-Based S3 ' +
                'remains the steady-state channel.'
        }));

        /* Dependency present? A disabled app is not usable (L1-03). */
        if (!env.awsTaPresent) {
            if (env.isDS) {
                /* Do NOT report a missing dependency here: the obvious
                 * remediation would be to install the AWS TA on the DS, which
                 * is the one tier this must not run on (L1-04). */
                root.appendChild(banner('warn', 'This is a deployment server',
                    ['Direct S3 polling runs on the instance that holds the input, so this screen ' +
                     'belongs on your heavy forwarders. Open it there.',
                     'Do not install the Splunk Add-on for AWS here to make this screen work.']));
            } else if (env.awsTaDisabled) {
                root.appendChild(banner('warn', 'The Splunk Add-on for AWS is disabled',
                    ['Enable it on this instance, then reload this page.']));
            } else {
                root.appendChild(banner('warn', 'The Splunk Add-on for AWS is not installed',
                    ['This screen configures inputs that belong to that add-on. Install it on ' +
                     'this instance, then reload this page.']));
            }
            return;
        }

        if (env.awsTaVersion && VALIDATED_TA_AWS_VERSIONS.indexOf(env.awsTaVersion) === -1) {
            root.appendChild(banner('warn',
                'Splunk Add-on for AWS ' + env.awsTaVersion + ' is not a validated version',
                ['This screen was validated against ' + VALIDATED_TA_AWS_VERSIONS.join(', ') + '. ' +
                 'Field names, the create and update rules, and — most importantly — what the ' +
                 'scan-window dates actually bound may differ in this version. Verify before ' +
                 'relying on a backfill.']));
        }

        if (env.dsManagedAwsTa === true) {
            root.appendChild(banner('error', 'The AWS add-on here is managed by your deployment server',
                ['Inputs created on this screen live in that add-on’s local/inputs.conf and are ' +
                 'destroyed on the next deployment push. Add the input to the server-class copy ' +
                 'on your deployment server instead — the generated stanza below is what to add.']));
            env.mode = 'assisted';
        }

        if (env.isDS) {
            root.appendChild(banner('warn', 'This instance is also a deployment server',
                ['An input created here polls from here. It is not distributed to your forwarders.']));
        }

        if (env.probeFailed) {
            root.appendChild(banner('warn', 'Could not confirm your capabilities',
                ['Showing the read-only view with generated configuration rather than risking a ' +
                 'write that would fail.']));
        }

        if (!env.accounts.length) {
            root.appendChild(banner('warn', 'No AWS accounts are configured',
                ['The Splunk Add-on for AWS is installed but has no account configured, so an ' +
                 'input cannot be created. Add one in that add-on’s Configuration → Account, ' +
                 'then reload this page.']));
            renderList(root, env);
            return;
        }

        if (!tierGate(root, env)) { renderList(root, env); return; }

        renderList(root, env);
        if (!state.form) { state.form = newForm(env); }
        renderEditor(root, env);
        renderVerify(root, env);
    }

    function renderVerify(container, env) {
        var section = el('div', { cls: 'logserv-s3-section' });
        section.appendChild(el('h3', { text: 'Did the backfill actually land?' }));
        section.appendChild(el('p', {
            text: 'The add-on keeps run state in a checkpoint file this screen cannot read, so a ' +
                'past "scan until" does not prove a run finished. Check both of these.'
        }));
        section.appendChild(copyable('Did the input finish its scan?',
            'index=_internal source=*splunk_ta_aws* datainput="' + NAME_PREFIX + '*" ' +
            '| stats count by datainput, log_level'));
        section.appendChild(copyable('Did events actually reach the index?',
            'index=' + (state.form && state.form.index ? state.form.index : SOURCETYPE) +
            ' sourcetype=' + SOURCETYPE + ' | stats count by sourcetype, host'));
        container.appendChild(section);
    }

    function reload() {
        probe().then(function (env) {
            state.env = env;
            if (!state.editing) { state.form = newForm(env); }
            render();
        });
    }

    /* ---------------------------------------------------------------- *
     * Entry
     * ---------------------------------------------------------------- */

    function boot() {
        clear(root);
        root.appendChild(el('p', { text: 'Checking this instance…' }));
        probe().then(function (env) {
            state.env = env;
            state.form = newForm(env);
            render();
        }).catch(function (e) {
            console.error('LogServ S3 Direct: probe failed', e);
            clear(root);
            root.appendChild(banner('error', 'Could not read this instance',
                ['See the browser console for detail.']));
        });
    }

    /**
     * Wait for the panel before starting.
     *
     * Splunk renders a SimpleXML <html> panel's content ASYNCHRONOUSLY, after
     * this script has already been evaluated, so the root div is not guaranteed
     * to exist yet. DOMContentLoaded does not help: the document is complete
     * well before the panel is. Poll, and say so in the console if the panel
     * never appears rather than failing silently.
     *
     * (The "Loading…" placeholder that the session-117 rendered pass found
     * stuck forever was NOT this — it was the anonymous define() described at
     * the top of the file, which meant none of this code ever ran. This poll is
     * defensive, not the fix.)
     */
    function start() {
        var tries = 0;
        (function awaitRoot() {
            root = document.getElementById(ROOT_ID);
            if (root) { boot(); return; }
            if (tries < MAX_ROOT_TRIES) {
                tries += 1;
                window.setTimeout(awaitRoot, ROOT_POLL_MS);
                return;
            }
            console.warn('LogServ S3 Direct: panel root #' + ROOT_ID +
                ' never appeared after ' + (MAX_ROOT_TRIES * ROOT_POLL_MS / 1000) + 's');
        }());
    }

    start();

    window[LOADED_FLAG] = true;
    return { start: start };
}());
