[filter_settings]
days_in_past = 
exclude_filters = 
exclude_sources = 
filter_enabled = 
include_filters = 
include_sources = 

[cloud_provider_settings]
cloud_provider = 
